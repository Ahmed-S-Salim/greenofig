import{j as o}from"./vendor-ui-B_k4QX8z.js";import{N as r}from"./vendor-react-CIJUevwt.js";const a=()=>o.jsx(r,{to:"/app",replace:!0});export{a as default};
